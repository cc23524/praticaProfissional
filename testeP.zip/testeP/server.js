const express = require('express');
const path = require('path');
const mainController = require('./src/Controller/mainController.js'); // Substitua pelo caminho correto do seu controller

const app = express();

app.use(express.static(path.join(__dirname, 'public')));

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.get('/', (req, res) => {
  res.render('index');
});

// Adicione as rotas diretamente ao objeto app
app.get('/pratos', mainController.getPratosPage);
app.get('/bebidas', mainController.getBebidasPage);
app.get('/sobremesas', mainController.getSobremesasPage);
app.get('/contatos', mainController.getContatosPage);
app.get('/login', mainController.getLoginPage);

app.get('/Carrinho', (req, res) => {
  res.render('Carrinho');
});

app.get('/index', (req, res) => {
  res.render('index');
});

const PORT = process.env.PORT || 3001;

app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});
