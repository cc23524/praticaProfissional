DELETE FROM Cliente
WHERE ID_cliente = 1;

DELETE FROM Login
WHERE ID_login = 1;

DELETE FROM Produto
WHERE ID_produto = 1;

DELETE FROM Avaliacao
WHERE ID_avaliacao = 1;

DELETE FROM Pedido
WHERE ID_pedido = 1;



