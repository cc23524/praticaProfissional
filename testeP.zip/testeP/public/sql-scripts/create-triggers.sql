CREATE OR REPLACE TRIGGER validar_nome_cliente
BEFORE INSERT ON Cliente
FOR EACH ROW
BEGIN
    
    IF :NEW.Nome IS NULL OR TRIM(:NEW.Nome) = '' THEN
        RAISE_APPLICATION_ERROR(-20001, 'O nome do cliente é obrigatório.');
    END IF;
END;
/