INSERT INTO Cliente (ID_cliente, Nome, Telefone, Email)
VALUES 
(1, 'Maria', '123456789', 'Maria@email.com');
(1, 'jose', '123456789', 'Jose@email.com');
(1, 'rosa', '123456789', 'Rosa@email.com');

INSERT INTO Login (ID_login, Usuario, Senha, Nivel_acesso)
VALUES 
(1, '@Maria', 'Exemplo_senha', 1);
(2, '@jose', 'Exemplo_senha', 1);
(3, '@rosa', 'Exemplo_senha', 1);

INSERT INTO Prato (ID_produto, Nome, Descricao, Preco, Categoria, Quantidade, Data_lancamento)
VALUES 
(1, 'Risoto', 'Descricao_prato', 69.90, 'Massas', 10, '2023-10-20');
(2, 'Sofioli', 'Descricao_prato', 69.90, 'Massas', 10, '2023-10-20');
(3, 'Espaguete', 'Descricao_prato', 69.90, 'Massas', 10, '2023-10-20');

INSERT INTO Avaliacao (ID_avaliacao, ID_cliente, Classificacao, Data_avaliacao)
VALUES 
(1, 1, 5, '2023-10-20');
(2, 2, 5, '2023-10-20');
(3, 3, 5, '2023-10-20');

INSERT INTO Pedido (ID_pedido, Data_hora, Status, ID_avaliacao)
VALUES ;
(1, '2023-10-20 14:31:00', 'Em andamento', 1)
(2, '2023-10-20 14:32:00', 'Finalizado', 2)
(3, '2023-10-20 14:35:00', 'Em andamento', 3)