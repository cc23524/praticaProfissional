const db = require('../db');

const mainController = {
    getHomePage: (req, res) => {
      res.render('index');
    },
    
    getPratosPage: (req, res) => {
      res.render('Pratos');
    },
  
    getBebidasPage: (req, res) => {
      res.render('bebidas');
    },
  
    getSobremesasPage: (req, res) => {
      res.render('sobremesas');
    },
  
    getContatosPage: (req, res) => {
      res.render('Contatos');
    },
  
    getLoginPage: (req, res) => {
      res.render('login');
    },
  };
  
  module.exports = mainController;
  