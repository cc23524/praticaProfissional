const sql = require('mssql');

const config = {
  user: 'BD23506',
  password: 'BD23506',
  server: 'regulus.cotuca.unicamp.br',
  database: 'BD23506',
  options: {
    encrypt: true,
    trustServerCertificate: true,
  },
};



const pool = new sql.ConnectionPool(config);

// Abre a conexão com o banco de dados
pool.connect().then(() => {
  console.log('Conexão com o banco de dados estabelecida com sucesso.');
}).catch((error) => {
  console.error('Erro ao conectar ao banco de dados:', error);
});

// Exporta a instância do pool
module.exports = pool;