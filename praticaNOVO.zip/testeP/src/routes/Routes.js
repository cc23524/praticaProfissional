const mainController = require('./src/Controller/mainController.js.js'); // Substitua pelo caminho correto do seu controller
const express = require('express');
const router = express.Router();

// Rota para a página inicial
router.get('/', mainController.getHomePage);

// Rotas para as páginas específicas
router.get('/pratos', mainController.getPratosPage);
router.get('/bebidas', mainController.getBebidasPage);
router.get('/sobremesas', mainController.getSobremesasPage);
router.get('/contatos', mainController.getContatosPage);
router.get('/login', mainController.getLoginPage);

// Outras rotas necessárias podem ser adicionadas aqui

module.exports = router;
